package networking

object ApiHelper {

    private const val api_key="b57fe1e109227dfaa3ee99a782376285"
    private const val city_name="New York"
    const val cnt="60"


    fun getUrl(): String? {

        return "https://api.openweathermap.org/data/2.5/weather?q="+ city_name +
                "&appid="+api_key

    }

    fun getForeCastUrl(): String? {

        return "https://api.openweathermap.org/data/2.5/forecast?q="+ city_name +
                "&appid="+ api_key+"&cnt="+ cnt

    }

}
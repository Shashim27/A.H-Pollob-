package viewModels

import android.app.Application
import android.content.Context
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import dataClasses.ForeCast
import dataClasses.Weather
import dataClasses.WeatherData
import repositories.ForeCastRepo
import repositories.WeatherRepo

class ForeCastViewModel(context: Context) : ViewModel() {

    val foreCastData: MutableLiveData<ForeCast>
    private val mRepository: ForeCastRepo = ForeCastRepo(context)

    init {
        foreCastData = mRepository.mutableLiveData
    }


}
package viewModels

import android.app.Application
import android.content.Context
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import dataClasses.Weather
import dataClasses.WeatherData
import repositories.WeatherRepo

class WeatherViewModel(context: Context) : ViewModel() {

    val weatherData: MutableLiveData<WeatherData>
    private val mRepository: WeatherRepo = WeatherRepo(context)

    init {
        weatherData = mRepository.mutableLiveData
    }


}
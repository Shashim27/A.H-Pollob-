package fragments

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import androidx.navigation.NavController
import androidx.navigation.NavDirections
import androidx.navigation.fragment.NavHostFragment
import com.hashim.weatherforecast.R
import kotlinx.android.synthetic.main.fragment_home.*
import viewModels.WeatherViewModel
import viewModels.WeatherViewModelFactory


class HomeFragment : Fragment() {


    private lateinit var weatherViewModel: WeatherViewModel

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {

        weatherViewModel = ViewModelProvider(this, WeatherViewModelFactory(requireContext())).get(
            WeatherViewModel::class.java
        )



        return inflater.inflate(R.layout.fragment_home, container, false)
    }


    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)


        weatherViewModel.weatherData.observe(viewLifecycleOwner, Observer {


            progressView.visibility=View.GONE

            val celsius= (it.main?.temp!! - 273.15).toInt()
            val fahrenheit= ((it.main?.temp!! - 273.15) *(9/5 )+ (32)).toInt()
            val mFeelLike= ((it.main?.feelsLike!! - 273.15) *(9/5 )+ (32)).toInt()

            weather.text= it.weather?.get(0)?.main
            temp.text= "$celsius °C"
            humidity.text= "Humidity: "+it.main?.humidity.toString()+"%"
            pressure.text= "Pressure: "+it.main?.pressure.toString()+" hpa"
            city.text=it.name


        })

        foreCastBtn.setOnClickListener {
            navigate(HomeFragmentDirections.homeToForeCast())
        }
    }


    private fun navigate(id:NavDirections){

        val navController: NavController = NavHostFragment.findNavController(this)
        navController.navigate(id)

    }



}
package fragments

import adapters.ForeCastAdapter
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import androidx.navigation.fragment.findNavController
import com.hashim.weatherforecast.R
import dataClasses.ForeCastList
import kotlinx.android.synthetic.main.fragment_fore_cast.*
import viewModels.ForeCastViewModel
import viewModels.ForeCastViewModelFactory


class ForeCastFragment : Fragment() {


    private lateinit var foreCastViewModel: ForeCastViewModel
    private var dataList= mutableListOf<ForeCastList>()


    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {

        foreCastViewModel= ViewModelProvider(this,
            ForeCastViewModelFactory(requireContext()))[ForeCastViewModel::class.java]

        return inflater.inflate(R.layout.fragment_fore_cast, container, false)
    }


    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        foreCastViewModel.foreCastData.observe(viewLifecycleOwner, Observer {

           for(item in it.foreCastList!!){

               val dateArray=item.dtTxt?.split(" ")
               val date= dateArray!![0]

               val data=ForeCastList()
               data.clouds=item.clouds
               data.dt=item.dt
               data.main=item.main
               data.pop=item.pop
               data.rain=item.rain
               data.sys=item.sys
               data.visibility=item.visibility
               data.wind=item.wind
               data.weather=item.weather
               data.dtTxt=date


               if(!dataList.contains(data)){
                   dataList.add(data)
               }


           }

            progressView.visibility=View.GONE
            initAdapter(it.city?.name.toString())


        })

        backBtn.setOnClickListener {
            findNavController().navigateUp()
        }

    }



    private fun initAdapter(city: String){

        val adapter=ForeCastAdapter(requireContext(),dataList,city,null)
        recyclerView.adapter=adapter
    }


}
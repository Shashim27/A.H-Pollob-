package dataClasses

import com.google.gson.annotations.SerializedName
import com.google.gson.annotations.Expose

class Clouds {
    @SerializedName("all")
    @Expose
    var all: Int? = null
}
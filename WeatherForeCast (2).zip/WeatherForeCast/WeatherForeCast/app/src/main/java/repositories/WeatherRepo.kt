package repositories

import android.content.Context
import android.util.Log
import networking.ApiHelper.getUrl
import androidx.lifecycle.MutableLiveData
import dataClasses.WeatherData
import com.android.volley.Request
import com.android.volley.toolbox.JsonObjectRequest
import com.android.volley.toolbox.Volley
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken

class WeatherRepo(private val mContext: Context) {

    val mutableLiveData = MutableLiveData<WeatherData>()
    private val weatherData: Unit

        get() {
            val url = getUrl()
            var weatherData=WeatherData()
            val stringRequest = JsonObjectRequest(
                Request.Method.GET,
                url,
                null,
                {

                    val gson = Gson()
                    val listType = object : TypeToken<WeatherData?>() {}.type

                    val data: WeatherData =
                        gson.fromJson<WeatherData>(it.toString(), listType)


                    weatherData.weather=data.weather
                    weatherData.main=data.main
                    weatherData.clouds=data.clouds
                    weatherData.cod=data.cod
                    weatherData.coord=data.coord
                    weatherData.base=data.base
                    weatherData.visibility=data.visibility
                    weatherData.dt=data.dt
                    weatherData.sys=data.sys
                    weatherData.timezone=data.timezone
                    weatherData.id=data.id


                    mutableLiveData.postValue(data)


                }) {
                Log.v("weatherData",it.message.toString())


            }
            val rQueue = Volley.newRequestQueue(mContext)
            rQueue.add(stringRequest)


        }

    init {
        weatherData
    }
}
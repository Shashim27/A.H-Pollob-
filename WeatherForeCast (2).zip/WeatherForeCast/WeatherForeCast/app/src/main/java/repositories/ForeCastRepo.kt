package repositories

import android.content.Context
import android.util.Log
import androidx.lifecycle.MutableLiveData
import networking.ApiHelper.getForeCastUrl
import com.android.volley.Request
import com.android.volley.toolbox.JsonObjectRequest
import com.android.volley.toolbox.Volley
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import dataClasses.ForeCast

class ForeCastRepo(private val mContext: Context) {

    val mutableLiveData = MutableLiveData<ForeCast>()
    private val weatherData: Unit

        get() {
            val url = getForeCastUrl()
            var foreCastData=ForeCast()
            val stringRequest = JsonObjectRequest(
                Request.Method.GET,
                url,
                null,
                {

                    val gson = Gson()
                    val listType = object : TypeToken<ForeCast?>() {}.type

                    val data: ForeCast =
                        gson.fromJson<ForeCast>(it.toString(), listType)


                    Log.v("weatherData",data.city?.name.toString())

                    mutableLiveData.postValue(data)


                }) {
                Log.v("weatherData",it.message.toString())


            }
            val rQueue = Volley.newRequestQueue(mContext)
            rQueue.add(stringRequest)


        }

    init {
        weatherData
    }
}
package adapters

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.hashim.weatherforecast.R
import dataClasses.ForeCastList
import kotlinx.android.synthetic.main.forecast_lite_item.view.*


class ForeCastAdapter(context: Context, var list: List<ForeCastList>,val city:String, listener:ClickListener?) :
    RecyclerView.Adapter<ForeCastAdapter.ForeCastHolder>() {

    private val sectionItemsList: List<ForeCastList> = list
    private val mContext: Context = context
    private var clickListener: ClickListener?=listener

    interface ClickListener { fun onSectionClick(position: Int, v: View?) }




    inner class ForeCastHolder (v: View) : RecyclerView.ViewHolder(v),
        View.OnClickListener {

        init {
            itemView.setOnClickListener(this)
        }

        override fun onClick(v: View) {
            clickListener?.onSectionClick(adapterPosition, v)
        }


    }


    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ForeCastHolder {
        val itemView: View = LayoutInflater.from(parent.context)
            .inflate(R.layout.forecast_lite_item, parent, false)
        return ForeCastHolder(itemView)
    }

    override fun onBindViewHolder(holder: ForeCastHolder, position: Int) {

        val it= list[position]

        val celsius= (it.main?.temp!! - 273.15).toInt()
        val mFeelLike= ((it.main?.feelsLike!! - 273.15) *(9/5 )+ (32)).toInt()

        holder.itemView.date.text=it.dtTxt
        holder.itemView.weather.text= it.weather?.get(0)?.main
        holder.itemView.weatherDes.text= it.weather?.get(0)?.description
        holder.itemView.temp.text= "$celsius °C"
        holder.itemView.feelLike.text= "Feels like: $mFeelLike °F"
        holder.itemView.humidity.text= "Humidity: "+it.main?.humidity.toString()+"%"
        holder.itemView.uv.text= "UV Index: "+it.sys?.type.toString()
        holder.itemView.pressure.text="Pressure: "+it.main?.pressure.toString()+" hpa"

        holder.itemView.city.text=city

    }

    override fun getItemCount(): Int {
        return sectionItemsList.size
    }

    override fun getItemId(position: Int): Long {
        return position.toLong()
    }




}
